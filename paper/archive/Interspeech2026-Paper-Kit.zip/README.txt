It is essential to read the complete set of instructions provided within the template before creating your manuscript for submission to Interspeech 2026.

Templates are provided for both LaTeX and Microsoft Word. The organisers strongly recommend LaTeX, because the template provides many useful features and generates documents easier to process for publication and archiving.

Note: the Microsoft Word template is not included in the Paper Kit from the Overleaf Gallery.

Files included:

LaTeX
-----

Interspeech.cls - defines the Interspeech document class

IEEEtran.bst - BibTeX Bibliography Style file

template.tex - the template in LaTeX format: start from this to create your own manuscript

mybib.bib - example bibliography for use with LaTeX + BibTeX

for_review.pdf - the output from template.tex created with the correct settings for double-blind review, with author names & affiliations redacted *** READ THIS DOCUMENT: it contains important instructions that you need to follow ***

camera_ready.pdf - the output from template.tex created with the correct settings for publication, with author names & affiliations revealed

Microsoft Word
--------------

A basic template providing the necessary styles is provided in the Paper Kit available from the conference website. Authors must refer to the above PDFs for full instructions and manuscript specifications.
